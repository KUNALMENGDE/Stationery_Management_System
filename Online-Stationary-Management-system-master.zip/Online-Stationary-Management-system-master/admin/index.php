<html>
<head>
<link rel="stylesheet" type="text/css" href="home.css"/>
<script src="home.js"></script>
<link rel="shortcut icon" href="large.png" />
</head>
<body>

<nav class="navbar">
      <div class="container">
       <link rel="shortcut icon" href="large.png" />
        <img src="large.png" alt="HTML5 Icon" style="width:128px;height128px;"> 
       
        <ul class="nav">
          <li><a href="../index.php">Home</a></li>
          <li><a href="login.php">Login</a></li>
          <li><a href="order.php">Orders</a></li>
          <!-- <li><a href="#specs">Specs</a></li>
					<li><a href="#contact">Contact</a></li> -->
        </ul>
      </div>
    </nav>

<center>
<h1 class="header"> Welcome To Admin Panel <br /> <marquee>First you have to login first</marquee>


 <button onclick="window.location.href = 'login.php';" class="btn success">Login</button>
</h1>
<footer class="footer1">

<center>
Copyright &copy <a href="">Stationary Shop</a> Store. All Rights Reserved.

</center>

</footer>
</body>
</html>
